<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <img class="brand-logo" src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo/lobirent-logo.jpg'); ?>" alt="Lobirent logo">
      <span>Lobirent</span>
    </a>
    <nav class="main-nav">
      <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'lobirent_fallback_menu')); ?>
    </nav>
  </div>
</header>
<?php
function lobirent_fallback_menu() {
  echo '<ul>';
  echo '<li><a href="#gundem">Gündem</a></li>';
  echo '<li><a href="#haberler">Haberler</a></li>';
  echo '<li><a href="#forum">Forum</a></li>';
  echo '<li><a href="#kategoriler">Kategoriler</a></li>';
  echo '</ul>';
}
?>
<main>
